import React, { Component } from 'react';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseDetails from './CourseDetails';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      view: 'book' // Possible values: 'book', 'blog', 'course'
    };
  }

  renderComponentUsingIf() {
    const { view } = this.state;
    if (view === 'book') {
      return <BookDetails />;
    } else if (view === 'blog') {
      return <BlogDetails />;
    } else {
      return <CourseDetails />;
    }
  }

  renderComponentUsingTernary() {
    const { view } = this.state;
    return (
      view === 'book' ? <BookDetails />
      : view === 'blog' ? <BlogDetails />
      : <CourseDetails />
    );
  }

  renderComponentUsingElementVariable() {
    let component;
    if (this.state.view === 'book') {
      component = <BookDetails />;
    } else if (this.state.view === 'blog') {
      component = <BlogDetails />;
    } else {
      component = <CourseDetails />;
    }
    return component;
  }

  render() {
    return (
      <div style={{ padding: '20px', fontFamily: 'Arial' }}>
        <h1>Blogger App - Conditional Rendering</h1>

        <div style={{ marginBottom: '20px' }}>
          <button onClick={() => this.setState({ view: 'book' })}>Show Book Details</button>
          <button onClick={() => this.setState({ view: 'blog' })}>Show Blog Details</button>
          <button onClick={() => this.setState({ view: 'course' })}>Show Course Details</button>
        </div>

        <hr />

        <h3>Rendered Using If-Else:</h3>
        {this.renderComponentUsingIf()}

        <h3>Rendered Using Ternary Operator:</h3>
        {this.renderComponentUsingTernary()}

        <h3>Rendered Using Element Variable:</h3>
        {this.renderComponentUsingElementVariable()}
      </div>
    );
  }
}

export default App;
