import React from 'react';

const UserPage = () => {
  return (
    <div>
      <h2>Welcome, User!</h2>
      <p>You can now book tickets for the following flights:</p>
      <ul>
        <li>
          ✈️ Mumbai → Delhi | ₹4500 <button>Book Now</button>
        </li>
        <li>
          ✈️ Chennai → Bengaluru | ₹3200 <button>Book Now</button>
        </li>
        <li>
          ✈️ Hyderabad → Pune | ₹4000 <button>Book Now</button>
        </li>
      </ul>
    </div>
  );
};

export default UserPage;
