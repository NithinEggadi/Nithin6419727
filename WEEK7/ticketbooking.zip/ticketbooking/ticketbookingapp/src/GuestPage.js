import React from 'react';

const GuestPage = () => {
  return (
    <div>
      <h2>Welcome, Guest!</h2>
      <p>You can browse available flight details below:</p>
      <ul>
        <li>✈️ Mumbai → Delhi | ₹4500</li>
        <li>✈️ Chennai → Bengaluru | ₹3200</li>
        <li>✈️ Hyderabad → Pune | ₹4000</li>
      </ul>
    </div>
  );
};

export default GuestPage;
