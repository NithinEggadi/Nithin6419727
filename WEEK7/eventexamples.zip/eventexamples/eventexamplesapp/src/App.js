import React, { Component } from 'react';
import CurrencyConvertor from './CurrencyConvertor';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
      message: ''
    };
  }

  incrementCounter = () => {
    this.setState(prevState => ({ counter: prevState.counter + 1 }));
    this.sayHello();
  };

  decrementCounter = () => {
    this.setState(prevState => ({ counter: prevState.counter - 1 }));
  };

  sayHello = () => {
    this.setState({ message: 'Hello! This is a static message.' });
  };

  sayWelcome = (text) => {
    this.setState({ message: `Welcome Message: ${text}` });
  };

  handleSyntheticEvent = (event) => {
    this.setState({ message: 'I was clicked' });
    console.log('Synthetic Event:', event.type); // synthetic event example
  };

  render() {
    return (
      <div style={{ padding: '20px' }}>
        <h1>Event Handling Example</h1>

        <h2>Counter: {this.state.counter}</h2>
        <button onClick={this.incrementCounter}>Increment</button>
        <button onClick={this.decrementCounter}>Decrement</button>

        <div style={{ marginTop: '20px' }}>
          <button onClick={() => this.sayWelcome('welcome')}>
            Say Welcome
          </button>
        </div>

        <div style={{ marginTop: '20px' }}>
          <button onClick={this.handleSyntheticEvent}>
            Synthetic Event: OnPress
          </button>
        </div>

        <div style={{ marginTop: '20px', color: 'blue' }}>
          <strong>{this.state.message}</strong>
        </div>

        <hr />

        <CurrencyConvertor />
      </div>
    );
  }
}

export default App;
