import React, { Component } from 'react';

class CurrencyConvertor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      rupees: '',
      euro: ''
    };
  }

  handleChange = (e) => {
    this.setState({ rupees: e.target.value });
  };

  handleSubmit = () => {
    const { rupees } = this.state;
    const euroRate = 0.011; // Example rate: 1 INR = 0.011 EUR
    const euro = (rupees * euroRate).toFixed(2);
    this.setState({ euro });
  };

  render() {
    return (
      <div>
        <h2>Currency Convertor</h2>
        <input
          type="number"
          placeholder="Enter amount in INR"
          value={this.state.rupees}
          onChange={this.handleChange}
        />
        <button onClick={this.handleSubmit}>Convert</button>
        {this.state.euro && (
          <p>Equivalent in Euro: €{this.state.euro}</p>
        )}
      </div>
    );
  }
}

export default CurrencyConvertor;
