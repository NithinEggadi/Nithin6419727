import React from 'react';

const IndianPlayers = () => {
  const T20players = ['Kohli', 'Rohit', 'Hardik', 'Pant', 'Surya'];
  const RanjiTrophy = ['Pujara', 'Rahane', 'Shaw', 'Sarfaraz', 'Jadeja'];

  // Merge arrays using ES6 spread operator
  const allPlayers = [...T20players, ...RanjiTrophy];

  // Destructuring into odd and even players
  const oddPlayers = allPlayers.filter((_, index) => index % 2 !== 0);
  const evenPlayers = allPlayers.filter((_, index) => index % 2 === 0);

  return (
    <div>
      <h2>Indian Players</h2>
      <h3>Even Team</h3>
      <ul>
        {evenPlayers.map((player, idx) => (
          <li key={idx}>{player}</li>
        ))}
      </ul>
      <h3>Odd Team</h3>
      <ul>
        {oddPlayers.map((player, idx) => (
          <li key={idx}>{player}</li>
        ))}
      </ul>
    </div>
  );
};

export default IndianPlayers;
