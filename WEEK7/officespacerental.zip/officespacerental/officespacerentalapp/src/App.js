import React from 'react';

function App() {
  const offices = [
    {
      name: 'CyberHub Office',
      rent: 55000,
      address: 'DLF Cyber City, Gurugram',
      image: 'https://via.placeholder.com/300x200?text=CyberHub+Office'
    },
    {
      name: 'Powai Workspace',
      rent: 72000,
      address: 'Hiranandani Gardens, Mumbai',
      image: 'https://via.placeholder.com/300x200?text=Powai+Workspace'
    },
    {
      name: 'Bangalore TechPark',
      rent: 68000,
      address: 'Electronic City, Bangalore',
      image: 'https://via.placeholder.com/300x200?text=TechPark+Bangalore'
    },
    {
      name: 'Chennai Business Center',
      rent: 48000,
      address: 'Tidel Park, Chennai',
      image: 'https://via.placeholder.com/300x200?text=Chennai+Business+Center'
    }
  ];

  const rentStyle = rent => ({
    color: rent > 60000 ? 'green' : 'red',
    fontWeight: 'bold'
  });

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1 style={{ textAlign: 'center' }}>Office Space Rental App</h1>
      {offices.map((office, index) => (
        <div
          key={index}
          style={{
            border: '1px solid #ccc',
            marginBottom: '20px',
            padding: '15px',
            borderRadius: '10px',
            boxShadow: '2px 2px 10px rgba(0,0,0,0.1)'
          }}
        >
          <h2>{office.name}</h2>
          <img
            src={office.image}
            alt={office.name}
            style={{ width: '100%', maxWidth: '400px', height: 'auto' }}
          />
          <p style={rentStyle(office.rent)}>Rent: ₹{office.rent}</p>
          <p>Address: {office.address}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
