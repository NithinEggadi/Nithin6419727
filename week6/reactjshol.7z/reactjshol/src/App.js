import React from 'react';
import CohortDetails from './Components/CohortDetails';

function App() {
  const cohorts = [
    {
      status: 'Ongoing',
      name: 'ReactJS Training Cohort',
      startDate: '24th July 2025',
      endDate: '15th August 2025',
      instuctor:"John Doe"
    },
    {
       status: 'Completed',
      name: '.NET Training Cohort',
      startDate: '1th May 2025',
      endDate: '30th June 2025',
      instuctor:'Jane Smith'
    },
  ];

  return (
    <div className="App">
      

    </div>
  );
}

export default App;
