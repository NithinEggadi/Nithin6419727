import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to the first session of React</h1>
    </div>
  );
}

export default App;

